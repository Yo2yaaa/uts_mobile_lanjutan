package com.example.uts_mobile_lanjutan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
