import 'package:flutter/material.dart';

class CheckoutPage extends StatelessWidget {
  const CheckoutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Pembayaran'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text('Masukkan detail kartu kredit',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
                decoration: const InputDecoration(labelText: 'Nomor Kartu')),
            const SizedBox(height: 8),
            TextField(
                decoration: const InputDecoration(labelText: 'Nama Pemegang')),
            const SizedBox(height: 8),
            Row(children: const [
              Expanded(
                  child: TextField(
                      decoration:
                          InputDecoration(labelText: 'Berlaku hingga'))),
              SizedBox(width: 8),
              Expanded(
                  child:
                      TextField(decoration: InputDecoration(labelText: 'CVV'))),
            ]),
            const Spacer(),
            Row(children: [
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.greenAccent[400]),
                  onPressed: () {
                    Navigator.pushNamed(context, '/home');
                  },
                  child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('Lanjutkan')),
                ),
              )
            ])
          ],
        ),
      ),
    );
  }
}
