import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Profil'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
            const SizedBox(height: 12),
            const Text('Nama Pengguna',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: const [
                  ListTile(title: Text('Pesanan Saya')),
                  Divider(height: 1),
                  ListTile(title: Text('Pembayaran')),
                  Divider(height: 1),
                  ListTile(title: Text('Pengaturan')),
                ],
              ),
            ),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.greenAccent[400]),
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/');
              },
              child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('Keluar')),
            )
          ],
        ),
      ),
    );
  }
}
