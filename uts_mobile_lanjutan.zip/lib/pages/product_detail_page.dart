import 'package:flutter/material.dart';

class ProductDetailPage extends StatelessWidget {
  const ProductDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Detail Produk'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.asset('assets/images/person_box.png', height: 200),
            const SizedBox(height: 12),
            const Text('Mechanical Keyboard',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Harga: \$120', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            const Text(
                'Keyboard mekanik berkualitas dengan switch merah dan build solid.'),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.greenAccent[400]),
                    onPressed: () {
                      Navigator.pushNamed(context, '/cart');
                    },
                    child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('Tambah ke Keranjang')),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
