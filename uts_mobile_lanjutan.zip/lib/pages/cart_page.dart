import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Keranjang'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ListTile(
              leading: const Icon(Icons.keyboard),
              title: const Text('Mechanical Keyboard'),
              subtitle: const Text('Qty 1'),
              trailing: const Text('\$120'),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.mouse),
              title: const Text('Gaming Mouse'),
              subtitle: const Text('Qty 1'),
              trailing: const Text('\$40'),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.greenAccent[400]),
                    onPressed: () {
                      Navigator.pushNamed(context, '/checkout');
                    },
                    child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('Checkout')),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
