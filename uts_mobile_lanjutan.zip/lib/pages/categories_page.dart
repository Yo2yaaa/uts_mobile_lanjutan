import 'package:flutter/material.dart';

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kategori'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              _item('Keyboard', Icons.keyboard),
              _item('Mouse', Icons.mouse),
              _item('Motherboard', Icons.memory),
              _item('GPU', Icons.storage),
            ]),
      ),
    );
  }

  Widget _item(String title, IconData icon) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.green[50], borderRadius: BorderRadius.circular(12)),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 36, color: Colors.green),
        const SizedBox(height: 8),
        Text(title),
      ]),
    );
  }
}
