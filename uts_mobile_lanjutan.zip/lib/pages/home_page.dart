import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tech Store'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              color: Colors.green[50],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Expanded(
                        child: Image.asset('assets/images/person_box.png',
                            height: 120)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Elektronik Premium Di Depan Pintu Anda',
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold)),
                          SizedBox(height: 8),
                          Text(
                              'Promo terbaik untuk keyboard, mouse, dan komponen PC.'),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text('Kategori',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('Lihat Semua', style: TextStyle(color: Colors.green)),
              ],
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              children: [
                _catCard(context, 'Keyboard', Icons.keyboard, '/categories'),
                _catCard(context, 'Mouse', Icons.mouse, '/categories'),
                _catCard(context, 'Motherboard', Icons.discount, '/categories'),
                _catCard(context, 'GPU', Icons.memory, '/categories'),
              ],
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.greenAccent[400]),
                    onPressed: () {
                      Navigator.pushNamed(context, '/cart');
                    },
                    child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('Keranjang')),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _catCard(
      BuildContext context, String title, IconData icon, String route) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.green[50], borderRadius: BorderRadius.circular(12)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 36, color: Colors.green),
          const SizedBox(height: 8),
          Text(title),
        ]),
      ),
    );
  }
}
