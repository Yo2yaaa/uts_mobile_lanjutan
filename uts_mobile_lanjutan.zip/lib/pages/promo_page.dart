import 'package:flutter/material.dart';

class PromoPage extends StatelessWidget {
  const PromoPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Promo'),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Expanded(child: Image.asset('assets/images/person_box.png')),
              const SizedBox(height: 12),
              const Text('Mechanical Keyboard',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text(
                  'Keyboard mekanik berkualitas tinggi dengan backlight dan switch yang responsif.'),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.greenAccent[400]),
                onPressed: () {
                  Navigator.pushNamed(context, '/product');
                },
                child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    child: Text('Beli Sekarang')),
              )
            ],
          ),
        ),
      ),
    );
  }
}
