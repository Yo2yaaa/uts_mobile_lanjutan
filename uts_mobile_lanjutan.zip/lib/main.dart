import 'package:flutter/material.dart';
import 'pages/onboarding_page.dart';
import 'pages/home_page.dart';
import 'pages/categories_page.dart';
import 'pages/promo_page.dart';
import 'pages/product_detail_page.dart';
import 'pages/cart_page.dart';
import 'pages/checkout_page.dart';
import 'pages/profile_page.dart';

void main() {
  runApp(const UtsMobileApp());
}

class UtsMobileApp extends StatelessWidget {
  const UtsMobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS Mobile - Tech Store',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.white,
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const OnboardingPage(),
        '/home': (context) => const HomePage(),
        '/categories': (context) => const CategoriesPage(),
        '/promo': (context) => const PromoPage(),
        '/product': (context) => const ProductDetailPage(),
        '/cart': (context) => const CartPage(),
        '/checkout': (context) => const CheckoutPage(),
        '/profile': (context) => const ProfilePage(),
      },
    );
  }
}
